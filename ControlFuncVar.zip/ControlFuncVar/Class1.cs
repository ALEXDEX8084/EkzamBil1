﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ControlFuncVar
{
    public class functionY
    {
        public string Y(double x)
        {
            double y = 0;
            if (-4 <= x && x < -2)
            {
                y = x + 3;
                string StrY = y.ToString();
                return StrY;
            }
            else if (-2 <= x && x < 4)
            {
                y = -x / 2;
                string StrY = y.ToString();
                return StrY;
            }
            else if (4 <= x && x < 6)
            {
                y = -2;
                string StrY = y.ToString();
                return StrY;
            }
            else if (6 <= x && x < 10)
            {
                y = Math.Sqrt(2 * 2 - (x - 8) * (x - 8)) - 2;
                string StrY = y.ToString();
                return StrY;
            }
            else
            {
                string StrY = "Х не входит в заданный диапозон";
                return StrY;
            }
        }
    }
}


﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using ControlFuncVar;

namespace TestFunc
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void minus3_0returned()
        {
            //arrange
            double x = -3;
            string expected = "0";
            //act
            functionY c = new functionY();
            string actual = c.Y(x);
            //assert
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void minus5_nonereturned()
        {
            //arrange
            double x = -5;
            string expected = "Х не входит в заданный диапозон";
            //act
            functionY c = new functionY();
            string actual = c.Y(x);
            //assert
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void a10_nonereturned()
        {
            //arrange
            double x = 10;
            string expected = "Х не входит в заданный диапозон";
            //act
            functionY c = new functionY();
            string actual = c.Y(x);
            //assert
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void a3_min1and5returned()
        {
            //arrange
            double x = 3;
            string expected = "-1,5";
            //act
            functionY c = new functionY();
            string actual = c.Y(x);
            //assert
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void a5_minus2returned()
        {
            //arrange
            double x = 5;
            string expected = "-2";
            //act
            functionY c = new functionY();
            string actual = c.Y(x);
            //assert
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void a7_minus1tdreturned()
        {
            //arrange
            double x = 7;
            string expected = "-0,267949192431123";
            //act
            functionY c = new functionY();
            string actual = c.Y(x);
            //assert
            Assert.AreEqual(expected, actual);
        }

    }
}
